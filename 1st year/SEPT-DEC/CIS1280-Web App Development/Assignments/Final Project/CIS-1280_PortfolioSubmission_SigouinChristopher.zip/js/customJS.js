/*

 Project Name: PORTFOLIO SUBMISSION
 Filename: customCSS.css

 Author: Christopher Sigouin
 Date: 12/13/2014
 Purpose: PORTFOLIO SUBMISSION
 Dependencies:
	 bootstrap.min.css, font-awesome.min.css, customerCSS.css, bootstrapValidator.css,
	 jquery-1.11.1.js, bootstrap.js, customJS.js, bootstrapValidator.js,
	 index.html, webProjects.html, javaProjects.html, blogPage.html, about.html,
	 quotes.txt

 References: No references needed as no images besides my own were used


 */

// ====================================== JQUERY ============================================
$( document ).ready(function() {

	console.log("Jquery ready!");

	// JQUERY GETS THE DATA FROM A TEXT FILE, SPLITS IT UP INTO AN ARRAY THEN GETS A RANDOM NUMBER TO DISPLAY AN ELEMENT AT RANDOM
	$.get('quotes.txt', function(data) {
		var quoteData = data.split("|");
		document.getElementById("quoteArea").innerHTML = quoteData[NS_QUOTE_RANDOMIZER.randomNumber() -1 ];
	});

	// JQUERY DISPLAYS THE ABOUT.HTML PAGE AFTER CLICKING THE ABOUT BUTTON
	$("#about").click( function() {
		window.location = "about.html";
	});

	// THESE EXECUTE ONCE THE DOCUMENT HAS COMPLETED LOADING
	document.getElementById("dateDisplay").innerHTML = "CURRENT DATE: " + ns_DATE_FORMAT.displayDateAndTime();
	ns_PROGRESS_BAR_LOADER.startBar(); // Loads the progress bar each time per page load


});

/**
 *
 * NAMESPACE: ns_PROGRESS_BAR_LOADER
 *
 * Increments the loading bar just for effect before every page
 *
 * @type {{intervalVar: number, percentLoaded: number, startBar: Function, addToBar: Function, stopBar: Function}}
 */
var ns_PROGRESS_BAR_LOADER = {
	intervalVar: 0,
	percentLoaded: 0,
	startBar: function() {
		$("#test").hide();
		ns_PROGRESS_BAR_LOADER.intervalVar = setInterval(this.addToBar, 150);

	},
	addToBar: function() {
		ns_PROGRESS_BAR_LOADER.percentLoaded += 10;
		console.log(ns_PROGRESS_BAR_LOADER.percentLoaded)
		if( ns_PROGRESS_BAR_LOADER.percentLoaded == 110 ) {
			console.log("all done!");
			ns_PROGRESS_BAR_LOADER.stopBar();
			$(".loadingBar").fadeOut("fast", function() {
				$("#hideContent").fadeIn("slow");
			})
		} else {
			console.log("loading bar");
			$("#progressBar").css("width", ns_PROGRESS_BAR_LOADER.percentLoaded + "%").html(ns_PROGRESS_BAR_LOADER.percentLoaded + "%");
		}
	},
	stopBar: function() {
		clearInterval(ns_PROGRESS_BAR_LOADER.intervalVar);
	}

}
/**
 *
 * NAMESPACE: NS_DATE_FORMAT
 *
 * Returns a formatted date and time
 * 			eg.   November 10, 2014 @ 2:33pm
 *
 * @type {{formatTime: Function}}
 */
var ns_DATE_FORMAT = {
	date: new Date(),
	displayDateAndTime: function() {
				    return this.formatDate() + " @ " + this.formatTime();
	},
	formatDate: function() {
					var currentMonth = this.date.getMonth();
					var date = this.date.getDate();
					var year = this.date.getFullYear();

					//Determine month
					var months = [ "January", "February", "March", "April", "May", "June", "July",
					 			   "August", "September", "October", "November", "December" ]

					return months[currentMonth] + " " + date + ", " + year;
	},
	formatTime: function() {

					var hours = this.date.getHours();
					var minutes = this.date.getMinutes();
					var amOrPm = "am";

					if (hours > 11) {
						amOrPm = "pm";
					}
					if (hours > 12) {
						hours = hours - 12;
					}
					if (hours == 0) {
						hours = 12;
					}
					if (minutes < 10) {
						minutes = "0" + minutes;
					}

					return hours + ":" + minutes + amOrPm;
	}

}

/**
 *
 * NAMESPACE: NS_QUOTE_RANDOMIZER
 *
 * Returns a random number between 1 to 5
 *
 * @type {{randomNumber: Function}}
 */
var NS_QUOTE_RANDOMIZER = {

	randomNumber: function() {
		return Math.floor((Math.random() * 5) + 1);
	}

}


