<?php

/*################## CIS-2286 Internet Programming Part I PWC ##################
	Author: Christopher Sigouin
	Date: March 27, 2015
	Purpose: Assignment 6
	Dependencies: 

*/

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Resume of Christopher Sigouin</title>
		<link rel="stylesheet" type="text/css" href="myStyles.css">
	</head>
	<body>
