<?php

/*

################## CIS-2286 Internet Programming Part I PWC ##################
	 Author: Christopher Sigouin
	 Date: February 7, 2015
	 Purpose: Assignment 3
	 Dependencies:  style.css, navMenu.css, configMain.php, myFunctions.php, navMenu.php
	 References: See below...

 	BANNER IMAGE: http://www.freeclipartpics.com/vegetable-clipart-images/
 */

include "toolbox/configMain.php";
include "toolbox/myFunctions.php";

$page = "order"; # Used with navMenu.php ( Great idea btw Don :P )

?>

<!DOCTYPE html>
<html>
	<head>
		<title>Order Vegetables Page</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/navMenu.css">
	</head>
	<body>
		<div id="container" class="center">
			<h1>Organic Veggies! Come get em!</h1>
			<?php include "toolbox/navMenu.php"; ?>
		</div>

		<div class="formLayout center">
			<form method="post" action="processVeggies.php">
				<fieldset>
					<label for="veggiePotatoes"><?php echo QUANTITY_POTATOES; ?> lbs Potatoes, 
					                            <?php echo formatCurrency(PRICE_POTATOES); ?></label>
					<input type="text" name="veggiePotatoes"/>
				
					<label for="veggieCarrots"><?php echo QUANTITY_CARROTS; ?> lbs Carrots, 
											   <?php echo formatCurrency(PRICE_CARROTS); ?></label>
					<input type="text" name="veggieCarrots"/>
			
					<label for="veggieSprouts"><?php echo QUANTITY_SPROUTS; ?> lbs Sprouts, 
					                           <?php echo formatCurrency(PRICE_SPROUTS); ?></label>
					<input type="text" name="veggieSprouts"/>
				
					<label for="veggieCauliflower"><?php echo QUANTITY_CAULIFLOWER; ?> Cauliflower, 
					                               <?php echo formatCurrency(PRICE_CAULIFLOWER); ?></label>
					<input type="text" name="veggieCauliflower"/>

					<label for="firstName">First Name:</label>
					<input type="text" name="firstName"/>
				
					<label for="lastName">Last Name:</label>
					<input type="text" name="lastName"/>
			
					<label for="email">Email:</label>
					<input type="email" name="email"/>
				
					<label for="phoneNumber">Phone Number:</label>
					<input type="text" name="phoneNumber"/>
					
					<input type="submit" name="submit" value="Submit Order"/><br/>
				</fieldset>
			</form>
		</div>
	</body>
</html>