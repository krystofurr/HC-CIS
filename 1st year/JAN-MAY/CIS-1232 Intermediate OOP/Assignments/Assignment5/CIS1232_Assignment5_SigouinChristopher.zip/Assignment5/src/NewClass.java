/*
 * ========= CIS 1232 Intermediate Object Oriented Programming PWC ==========
 * NAME: Christopher Sigouin
 * DATE: 22-Mar-2015
 PURPOSE: 
 */

/**
 *
 * @author krystofurr
 */
public class NewClass {
    
}
