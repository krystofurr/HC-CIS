/*
 * ========= CIS 1232 Intermediate Object Oriented Programming PWC ==========
 * NAME: Christopher Sigouin
 * DATE: 8-Apr-2015
 * PURPOSE: Assignment 7
 */

/*

    RoomBase Class

*/
public abstract class RoomBase {
 
    private int roomNumber;
    private int numberOfSeats;

    public abstract void getRoomDetailsFromUser();

}
