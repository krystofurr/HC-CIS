/*
 * ========= CIS 1232 Intermediate Object Oriented Programming PWC ==========
 * NAME: Christopher Sigouin
 * DATE: 24-Apr-2015
 * PURPOSE: Assignment 8
 */
package exception;

/**
 *
 * @author krystofurr
 */
public class RoomReservationException extends Exception {

    public RoomReservationException(String message) {
        super(message);
    }

    
    
    
    
}
