/*
 * ========= CIS 1232 Intermediate Object Oriented Programming PWC ==========
 * NAME: Christopher Sigouin
 * DATE: 24-Apr-2015
 * PURPOSE: Assignment 8
 */
package exception;

/**
 *
 * @author krystofurr
 */
public class RoomExistException extends Exception {

    public RoomExistException(String message) {
        super(message);
    }

    
    
            
}
