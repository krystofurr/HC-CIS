/*
 * ========= CIS 1232 Intermediate Object Oriented Programming PWC ==========
 * NAME: Christopher Sigouin
 * DATE: 24-Apr-2015
 * PURPOSE: 
 */
package exception;

/**
 *
 * @author krystofurr
 */
public class RoomReleaseException extends Exception {

    public RoomReleaseException(String message) {
        super(message);
    }
    
    
    
}
