/*
 *  *** CIS-1232 Intermediate OOP ***
 * 
 * NAME: Christopher Sigouin
 * DATE: Feb 20 2015
 * PROJECT NAME: Assignment 4
 * DEPENDENCIES: None
 *
 */

public class Util {

	public final static boolean DEBUG = false;

}