/*
 *  *** CIS-1232 Intermediate OOP ***
 * 
 * NAME: Christopher Sigouin
 * DATE: 29-Jan-2015
 * PROJECT NAME: Assignment 2
 * DEPENDENCIES: None
 *
 */

public class Util {

	public static boolean debugging = false;

}