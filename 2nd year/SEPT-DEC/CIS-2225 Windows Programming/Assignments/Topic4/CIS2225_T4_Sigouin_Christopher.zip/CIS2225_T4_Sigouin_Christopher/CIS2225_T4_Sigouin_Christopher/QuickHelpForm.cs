﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS2225_T4_Sigouin_Christopher
{
    public partial class QuickHelpForm : Form
    {
        public QuickHelpForm()
        {
            InitializeComponent();
        }
    }
}
